package ch06.sec07.exam03;

public class Korean {
    String nation = "대한민국";
    String name;
    String ssn;


    Korean( String name, String ssn) {

        this.name = name;
        this.ssn = ssn;
    }

  



}
